import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './login';
import Professori from './professori'
import Domande from './domande'

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path='/professori' element={<Professori/>}></Route>
        <Route path='/domande' element={<Domande/>}></Route>
      </Routes>
    </Router>
  );
};

export default App;