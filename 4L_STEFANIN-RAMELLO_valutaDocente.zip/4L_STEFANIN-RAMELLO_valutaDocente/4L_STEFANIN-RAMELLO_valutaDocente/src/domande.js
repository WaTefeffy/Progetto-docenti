import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useParams } from 'react-router-dom';
import './App2.css';

const Domande = () => {
  const { id } = useParams();
  const [domande, setDomande] = useState([]);
  const [valutazioni, setValutazioni] = useState({});
  const [errore, setErrore] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchDomande = () => {
      fetch('https://raw.githubusercontent.com/1Lg20/ValutazioneDocenti/main/domandeProf.json')
        .then(response => {
          if (!response.ok) {
            throw new Error('Errore nel recupero delle domande');
          }
          return response.json();
        })
        .then(data => {
          console.log('Dati delle domande:', data);
          setDomande(data);
          // Inizializza le valutazioni a 5 per ogni domanda
          const initialValutazioni = {};
          data.forEach((domanda, index) => {
            initialValutazioni[index] = 5;
          });
          setValutazioni(initialValutazioni);
        })
        .catch(error => {
          console.error('Errore durante il recupero delle domande:', error.message);
          setErrore(error.message);
        });
    };

    console.log('ID del professore:', id);
    fetchDomande();
  }, [id]);

  // Funzione per aggiornare la valutazione in base all'indice della domanda
  const handleValutazioneChange = (index, valore) => {
    setValutazioni(prevValutazioni => ({
      ...prevValutazioni,
      [index]: valore
    }));
  };

  // Funzione per gestire l'invio delle valutazioni
  const handleSubmit = () => {
    console.log('Valutazioni inviate:', valutazioni);
    navigate("/Professori");
  };

  if (errore) {
    return <div className="container">Si è verificato un errore: {errore}</div>;
  }

  return (
    <div className='container'>
      <h2>DOMANDE PER L'INSEGNANTE</h2>
      <div className="row-12 list-group">
        {domande.map((domanda, index) => (
          <div key={index} className="col list-group-item">
            <p className="mb-0">{domanda.question}</p>
            <div className="mt-2">
              <label>Valutazione da 1 a 10:</label>
              <input id='selezione'
                type="number"
                min="1"
                max="10"
                value={valutazioni[index] || 5}
                onChange={(e) => handleValutazioneChange(index, e.target.value)}
              />
            </div>
          </div>
        ))}
      </div>
      <div className='row'>
        <div className='col-12 btn'>
          <button className="btn-invio btn-primary mt-3" onClick={handleSubmit}>
            Invia
          </button>
        </div>
      </div>
    </div>
  );
};

export default Domande;