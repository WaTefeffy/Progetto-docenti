import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';

const Domande = () => {
  const { id } = useParams();
  const [domande, setDomande] = useState([]);
  const [errore, setErrore] = useState(null);

  useEffect(() => {
    const fetchDomande = () => {
      fetch('https://raw.githubusercontent.com/1Lg20/ValutazioneDocenti/main/domandeProf.json')
        .then(response => {
          if (!response.ok) {
            throw new Error('Errore nel recupero delle domande');
          }
          return response.json();
        })
        .then(data => {
          console.log('Dati delle domande:', data);
          setDomande(data);
        })
        .catch(error => {
          console.error('Errore durante il recupero delle domande:', error.message);
          setErrore(error.message);
        });
    };

    console.log('ID del professore:', id);
    fetchDomande();
  }, [id]);

  if (errore) {
    return <div>Si è verificato un errore: {errore}</div>;
  }

  return (
    <div>
      <h2>Domande per l'insegnante</h2>
      <ul>
        {domande.map((domanda, index) => (
          <li key={index}>{domanda.question}</li>
        ))}
      </ul>
    </div>
  );
};

export default Domande;