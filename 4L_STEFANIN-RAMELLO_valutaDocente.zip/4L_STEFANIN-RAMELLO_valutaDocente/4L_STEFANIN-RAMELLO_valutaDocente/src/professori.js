import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './App1.css';

const Professori = () => {
  const [professori, setProfessori] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchProfessori = () => {
      fetch('https://raw.githubusercontent.com/1Lg20/ValutazioneDocenti/main/ProfJSON.json')
        .then(response => {
          if (!response.ok) {
            throw new Error('Errore nel recupero dei dati dei professori');
          }
          return response.json();
        })
        .then(data => {
          setProfessori(data);
        })
        .catch(error => {
          console.error('Errore durante il recupero dei dati:', error.message);
        });
    };

    fetchProfessori();
  }, []); // L'array vuoto come dipendenza fa sì che l'effetto venga eseguito solo una volta

  const handleButtonClick = (professoreId) => {
    navigate('/Domande');
  };

  return (
    <div className='container'>
      <div className='row row1'>
          LISTA DEI PROFESSORI
      </div>
      <div className="row professori-list">
        {professori.map(professore => (
          <div className='col-lg-4 col-xs-12' key={professore.id}>
              <button className="professore-button" onClick={() => handleButtonClick(professore.id)}>
                {professore.nome} Materia: {professore.materia}
              </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Professori;