import React from 'react'
import './App.css';
const App = () => {
  return (
    <div className='sfondo'>
      <div className='container tot'>
        <div className='row'>
          <div className='col-12 boh'>PROGETTO DOCENTI</div>
        </div>
        <div className='row'>
          <div className='col-12 mt-5 prova'>
            <input type='text' placeholder='INSERISCI IL NOME'></input>
          </div>
        </div>
        <div className='row'>
          <div className='col-12 mt-2 prova'>
            <input type='text' placeholder='INSERISCI LA CLASSE'></input>
          </div>
        </div>
        <div className='row'>
          <div className='col-12 mt-2 prova'>
            <input type='text' placeholder='INSERISCI LA SCUOLA'></input>
          </div>
        </div>
        <div className='row'>
          <div className='col-12 mt-2 prova'>
            <input type='button' value='LOGIN'></input>
          </div>
        </div>
      </div>
    </div>
  )
}

export default App