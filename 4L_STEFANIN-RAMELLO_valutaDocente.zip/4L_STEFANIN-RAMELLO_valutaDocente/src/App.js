import React, { useRef } from 'react'
import './App.css';
const App = () => {

  
  const user=useRef()
  const pwd=useRef()
  const classe=useRef()
  const istituto=useRef()


  const accedi=()=>{
    /*
    console.log("user: " + user.current.value)
    console.log("pwd: " + pwd.current.value)
    console.log("classe: " + classe.current.value)
    console.log("istituto: " + istituto.current.value)
    */
  }


  return (
    <div>
      <div className='container tot'>
        <div className='row'>
          <div className='col-12 title'>PROGETTO DOCENTI</div>
        </div>
        <div className='row mt-3'>
          <div className='col-12 dati'>I TUOI DATI:</div>
        </div>
        <div className='row mt-3'>
          <div className='col-5 prova'>USERNAME</div>
          <div className='col-6 prova2'>
            <input type='text' placeholder='INSERISCI USERNAME' ref={user}></input>
          </div>
        </div>
        <div className='row mt-3'>
          <div className='col-5 prova'>PASSWORD</div>
          <div className='col-6 prova2'>
            <input type='password' placeholder='INSERISCI PASSWORD' ref={pwd} ></input>
          </div>
        </div>
        <div className='row mt-3'>
          <div className='col-5 prova'>CLASSE</div>
          <div className='col-6 prova2'>
            <input type='text' placeholder='INSERISCI CLASSE' ref={classe} ></input>
          </div>
        </div>
        <div className='row mt-3'>
          <div className='col-5 prova'>ISTITUTO</div>
          <div className='col-6 prova2'>
            <input type='text' placeholder='INSERISCI ISTITUTO' ref={istituto} ></input>
          </div>
        </div>
        <div className='row'>
          <div className='col-12 mt-2 log'>
            <input type='button' value='LOGIN' onClick={accedi}></input>
          </div>
        </div>
      </div>
    </div>
  )
}

export default App