import React, { useRef } from 'react'
import { useNavigate } from 'react-router-dom';
import './App.css';


const App = () => {

  const navigate = useNavigate();
  const user=useRef()
  const pwd=useRef()
  


  const accedi=()=>{
    let username=user.current.value
    let password=pwd.current.value
    
    /*
    console.log("user: " + user.current.value)
    console.log("pwd: " + pwd.current.value)
    */
   
   fetch("https://raw.githubusercontent.com/1Lg20/ValutazioneDocenti/main/Credenziali.json")
   .then(response => response.json())
      .then(result => {
        const credenziali = result.find(utente => utente.username === username && utente.password === password);
        console.log(credenziali)
        if (credenziali) {
            console.log("Accesso consentito");
            navigate("/Professori");
          } else {
            alert("Credenziali non valide")
          }
      })
  }



  
  return (
    <div>
      <div className='container tot'>
        <div className='row'>
          <div className='col-12 title'>PROGETTO DOCENTI</div>
        </div>
        <div className='row mt-3'>
          <div className='col-12 dati'>I TUOI DATI:</div>
        </div>
        <div className='row mt-3'>
          <div className='col-5 prova'>USERNAME</div>
          <div className='col-6 prova2'>
            <input type='text' placeholder='INSERISCI USERNAME' ref={user}></input>
          </div>
        </div>
        <div className='row mt-3'>
          <div className='col-5 prova'>PASSWORD</div>
          <div className='col-6 prova2'>
            <input type='password' placeholder='INSERISCI PASSWORD' ref={pwd} ></input>
          </div>
        </div>
        <div className='row'>
          <div className='col-12 mt-3 log'>
            <input type='button' className='bottone' value='LOGIN' onClick={accedi}></input>
          </div>
        </div>
      </div>
    </div>
  )
}

export default App