import React, { useState, useEffect } from 'react';

const Professori = () => {
  const [professori, setProfessori] = useState([]);

  useEffect(() => {
    const fetchProfessori = () => {
      fetch('https://raw.githubusercontent.com/1Lg20/ValutazioneDocenti/main/ProfJSON.json')
        .then(response => {
          if (!response.ok) {
            throw new Error('Errore nel recupero dei dati dei professori');
          }
          return response.json();
        })
        .then(data => {
          setProfessori(data);
        })
        .catch(error => {
          console.error('Errore durante il recupero dei dati:', error.message);
        });
    };

    fetchProfessori();
  }, []); // L'array vuoto come dipendenza fa sì che l'effetto venga eseguito solo una volta

  const handleButtonClick = (professore) => {
    // Qui puoi gestire cosa succede quando viene cliccato un professore
    
  };

  return (
    <div>
      <h2>Lista dei Professori</h2>
      <ul>
        {professori.map(professore => (
          <li key={professore.id}>
            <button onClick={() => handleButtonClick(professore.id)}>
              {professore.nome} - Materia: {professore.materia}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Professori;
